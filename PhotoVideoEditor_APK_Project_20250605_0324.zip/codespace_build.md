# 🚀 GitHub Codespaces ile APK Build

## 📱 Cloud'da APK Oluşturmak (En Kolay Yöntem)

### 1️⃣ **GitHub Repository Hazırla**

1. **📁 GitHub'da yeni repository oluştur:**
   - Repository name: `PhotoVideoEditor-APK`
   - Public seç (Codespaces için)

2. **📦 Dosyaları upload et:**
   - `PhotoVideoEditor_APK_Project_20250605_0256.zip` unzip et
   - Tüm dosyaları repository'e drag & drop

### 2️⃣ **GitHub Codespaces Başlat**

1. **🌐 Repository sayfasında:**
   - Yeşil "Code" butonuna tıkla
   - "Codespaces" tab'ı seç
   - "Create codespace on main" buton

2. **⏳ Codespace yüklensin (2-3 dakika)**

### 3️⃣ **APK Build Komutları**

Codespace terminal'inde şu komutları çalıştır:

```bash
# Sistem güncelle
sudo apt update

# Gerekli paketleri kur
sudo apt install -y git zip unzip openjdk-11-jdk python3-pip \
  autoconf libtool pkg-config zlib1g-dev libncurses5-dev \
  libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev \
  build-essential libgl1-mesa-dev libgles2-mesa-dev

# Buildozer kur
pip install --upgrade pip
pip install buildozer
pip install kivy[base]

# APK build
buildozer android debug
```

### 4️⃣ **APK İndir**

Build tamamlandığında:

```bash
# APK dosyasını bul
ls -la bin/

# APK boyutunu kontrol et
du -h bin/*.apk

# APK'yı indirmek için GitHub web interface kullan
```

## 🔧 **Troubleshooting**

### ❌ Build hatası alırsan:

```bash
# Android SDK lisansını kabul et
yes | sdkmanager --licenses

# Cache temizle
buildozer appclean
buildozer android clean

# Tekrar build
buildozer android debug
```

### 🐛 Kivy hatası:

```bash
# Kivy bağımlılıklarını kur
sudo apt install python3-kivy

# Requirements güncelle
pip install -r requirements.txt
```

## ⚡ **Hızlı Script**

Tek komutla build:

```bash
#!/bin/bash
echo "🚀 PhotoVideoEditor APK Build başlıyor..."

# Sistem hazırlığı
sudo apt update && sudo apt install -y git zip unzip openjdk-11-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev build-essential libgl1-mesa-dev libgles2-mesa-dev

# Python bağımlılıkları
pip install --upgrade pip buildozer kivy[base]

# Android SDK lisansı
yes | buildozer android debug || echo "İlk deneme tamamlandı"

# APK build
buildozer android debug

echo "✅ Build tamamlandı! APK: bin/ klasöründe"
ls -la bin/
```

## 🎉 **Sonuç**

- ✅ **GitHub Codespaces** → Ücretsiz 60 saat/ay
- ✅ **Cloud Build** → Local kurulum gerektirmez
- ✅ **Otomatik Environment** → Tüm araçlar hazır
- ✅ **Fast Build** → Güçlü cloud sunucular

**5-10 dakikada APK hazır!** 🚀📱 