# ⚡ Quick Start Guide

## 🚀 En Hızlı Yöntem: GitHub Upload + Actions

### 📋 **5 Dakikada APK:**

1. **📁 GitHub Repository Oluştur**
   - github.com → + → New repository
   - Name: PhotoVideoEditor-APK
   - ✅ Public seç

2. **📦 Dosyaları Upload Et**
   - "uploading an existing file" tıkla
   - Bu ZIP'teki tüm dosyaları drag & drop
   - "Commit changes" tıkla

3. **🤖 Actions Bekle**
   - Actions tab → Build Android APK
   - 10-15 dakika bekle

4. **📱 APK İndir**
   - Artifacts → PhotoVideoEditor-debug-apk
   - ZIP aç → APK telefona kur

### 📋 **Alternatif: GitHub Codespaces**

1. **🌐 Repository'de:**
   - Code → Codespaces → Create

2. **⚡ Terminal'de:**
   ```bash
   chmod +x build_apk.sh
   ./build_apk.sh
   ```

3. **📱 APK hazır!**

## 📲 APK Telefona Yükleme:

1. **🔧 "Bilinmeyen kaynaklardan kurulum" açık**
2. **📁 APK dosyasını telefona taşı**  
3. **📱 APK'ya tıklayıp kur**
4. **🎉 PhotoVideoEditor çalışır!**

## 🆘 **Sorun mu var?**

- `github_upload_guide.md` - Detaylı rehber
- `upload_checklist.md` - Adım adım checklist
- `codespace_build.md` - Cloud build rehberi

**İyi kullanımlar! 🚀**
