"""
PhotoVideoEditor Mobile - Kivy Launcher Test Versiyonu
"""

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.progressbar import ProgressBar
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.logger import Logger


class SplashScreen(Screen):
    """Açılış ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
        
    def build_ui(self):
        """UI oluştur"""
        layout = BoxLayout(orientation='vertical', spacing=20, padding=50)
        
        # Logo
        logo = Label(
            text='📱 PhotoVideoEditor',
            font_size='32sp',
            size_hint=(1, 0.3),
            halign='center'
        )
        
        # Subtitle
        subtitle = Label(
            text='Video & Fotoğraf Düzenleyici',
            font_size='18sp',
            size_hint=(1, 0.2),
            halign='center',
            color=(0.7, 0.7, 0.7, 1)
        )
        
        # Loading bar
        self.progress = ProgressBar(
            max=100,
            value=0,
            size_hint=(0.8, 0.1),
            pos_hint={'center_x': 0.5}
        )
        
        # Loading text
        self.loading_text = Label(
            text='Yükleniyor...',
            font_size='14sp',
            size_hint=(1, 0.2),
            halign='center'
        )
        
        # Version
        version = Label(
            text='v1.0.0 - Mobile Test',
            font_size='12sp',
            size_hint=(1, 0.1),
            halign='center',
            color=(0.5, 0.5, 0.5, 1)
        )
        
        layout.add_widget(Label())  # Spacer
        layout.add_widget(logo)
        layout.add_widget(subtitle)
        layout.add_widget(Label())  # Spacer
        layout.add_widget(self.progress)
        layout.add_widget(self.loading_text)
        layout.add_widget(Label())  # Spacer
        layout.add_widget(version)
        
        self.add_widget(layout)
        
        # Loading animasyonu başlat
        anim = Animation(value=100, duration=2.5)
        anim.start(self.progress)


class MainMenuScreen(Screen):
    """Ana menü ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """Ana menü UI'ını oluştur"""
        main_layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        
        # Header
        header = Label(
            text='📱 PhotoVideoEditor\n(Mobile Test)',
            font_size='24sp',
            size_hint=(1, 0.2),
            halign='center'
        )
        
        # Menü butonları için grid
        button_grid = GridLayout(cols=2, spacing=15, size_hint=(1, 0.6))
        
        # Fotoğraf Düzenle butonu
        photo_btn = Button(
            text='📸\nFotoğraf\nDüzenle',
            halign='center',
            background_color=(0.2, 0.6, 0.8, 1),
            font_size='16sp'
        )
        photo_btn.bind(on_press=self.go_to_photo_editor)
        
        # Video Düzenle butonu
        video_btn = Button(
            text='🎬\nVideo\nDüzenle',
            halign='center',
            background_color=(0.8, 0.2, 0.4, 1),
            font_size='16sp'
        )
        video_btn.bind(on_press=self.go_to_video_editor)
        
        # Test butonu
        test_btn = Button(
            text='🧪\nTest\nÖzellikleri',
            halign='center',
            background_color=(0.4, 0.8, 0.2, 1),
            font_size='16sp'
        )
        test_btn.bind(on_press=self.show_test_info)
        
        # Hakkında butonu
        about_btn = Button(
            text='ℹ️\nHakkında',
            halign='center',
            background_color=(0.6, 0.6, 0.6, 1),
            font_size='16sp'
        )
        about_btn.bind(on_press=self.show_about)
        
        # Butonları grid'e ekle
        button_grid.add_widget(photo_btn)
        button_grid.add_widget(video_btn)
        button_grid.add_widget(test_btn)
        button_grid.add_widget(about_btn)
        
        # Footer
        footer = Label(
            text='Telefonunuzda çalışıyor! 🎉',
            font_size='14sp',
            size_hint=(1, 0.2),
            halign='center',
            color=(0.7, 0.7, 0.7, 1)
        )
        
        # Layout'a ekle
        main_layout.add_widget(header)
        main_layout.add_widget(button_grid)
        main_layout.add_widget(footer)
        
        self.add_widget(main_layout)
    
    def go_to_photo_editor(self, instance):
        """Fotoğraf editörüne git"""
        App.get_running_app().screen_manager.current = 'photo_editor'
    
    def go_to_video_editor(self, instance):
        """Video editörüne git"""
        App.get_running_app().screen_manager.current = 'video_editor'
    
    def show_test_info(self, instance):
        """Test bilgilerini göster"""
        App.get_running_app().screen_manager.current = 'test_info'
    
    def show_about(self, instance):
        """Hakkında sayfasını göster"""
        App.get_running_app().screen_manager.current = 'about'


class PhotoEditorScreen(Screen):
    """Fotoğraf editörü ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """UI oluştur"""
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        
        # Header
        header_layout = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        
        back_btn = Button(
            text='← Geri',
            size_hint=(0.3, 1),
            background_color=(0.5, 0.5, 0.5, 1)
        )
        back_btn.bind(on_press=self.go_back)
        
        title = Label(
            text='📸 Fotoğraf Editörü',
            font_size='18sp',
            size_hint=(0.7, 1),
            halign='center'
        )
        
        header_layout.add_widget(back_btn)
        header_layout.add_widget(title)
        
        # Content
        content = Label(
            text='🎉 Telefonunuzda çalışıyor!\n\n'
                 'Fotoğraf editörü özellikleri:\n'
                 '✅ Parlaklık ayarı\n'
                 '✅ Kontrast ayarı\n'
                 '✅ Filtreler\n'
                 '✅ Kırpma ve döndürme\n\n'
                 '(Yakında gelecek...)',
            font_size='16sp',
            halign='center',
            size_hint=(1, 0.9)
        )
        
        layout.add_widget(header_layout)
        layout.add_widget(content)
        
        self.add_widget(layout)
    
    def go_back(self, instance):
        """Ana menüye dön"""
        App.get_running_app().screen_manager.current = 'main_menu'


class VideoEditorScreen(Screen):
    """Video editörü ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """UI oluştur"""
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        
        # Header
        header_layout = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        
        back_btn = Button(
            text='← Geri',
            size_hint=(0.3, 1),
            background_color=(0.5, 0.5, 0.5, 1)
        )
        back_btn.bind(on_press=self.go_back)
        
        title = Label(
            text='🎬 Video Editörü',
            font_size='18sp',
            size_hint=(0.7, 1),
            halign='center'
        )
        
        header_layout.add_widget(back_btn)
        header_layout.add_widget(title)
        
        # Content
        content = Label(
            text='🎉 Telefonunuzda çalışıyor!\n\n'
                 'Video editörü özellikleri:\n'
                 '✅ Video kesme\n'
                 '✅ Filtreler\n'
                 '✅ Ses düzenleme\n'
                 '✅ Hız ayarı\n\n'
                 '(Yakında gelecek...)',
            font_size='16sp',
            halign='center',
            size_hint=(1, 0.9)
        )
        
        layout.add_widget(header_layout)
        layout.add_widget(content)
        
        self.add_widget(layout)
    
    def go_back(self, instance):
        """Ana menüye dön"""
        App.get_running_app().screen_manager.current = 'main_menu'


class TestInfoScreen(Screen):
    """Test bilgileri ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """UI oluştur"""
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        
        # Header
        header_layout = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        
        back_btn = Button(
            text='← Geri',
            size_hint=(0.3, 1),
            background_color=(0.5, 0.5, 0.5, 1)
        )
        back_btn.bind(on_press=self.go_back)
        
        title = Label(
            text='🧪 Test Bilgileri',
            font_size='18sp',
            size_hint=(0.7, 1),
            halign='center'
        )
        
        header_layout.add_widget(back_btn)
        header_layout.add_widget(title)
        
        # Content
        import platform
        content = Label(
            text=f'📱 Cihaz Bilgileri:\n\n'
                 f'Platform: {platform.system()}\n'
                 f'Python: {platform.python_version()}\n'
                 f'Kivy: Çalışıyor ✅\n'
                 f'UI: Responsive ✅\n'
                 f'Touch: Destekleniyor ✅\n\n'
                 f'🎉 Uygulama mobil cihazınızda\n'
                 f'başarıyla çalışıyor!',
            font_size='16sp',
            halign='center',
            size_hint=(1, 0.9)
        )
        
        layout.add_widget(header_layout)
        layout.add_widget(content)
        
        self.add_widget(layout)
    
    def go_back(self, instance):
        """Ana menüye dön"""
        App.get_running_app().screen_manager.current = 'main_menu'


class AboutScreen(Screen):
    """Hakkında ekranı"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build_ui()
    
    def build_ui(self):
        """UI oluştur"""
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        
        # Header
        header_layout = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        
        back_btn = Button(
            text='← Geri',
            size_hint=(0.3, 1),
            background_color=(0.5, 0.5, 0.5, 1)
        )
        back_btn.bind(on_press=self.go_back)
        
        title = Label(
            text='ℹ️ Hakkında',
            font_size='18sp',
            size_hint=(0.7, 1),
            halign='center'
        )
        
        header_layout.add_widget(back_btn)
        header_layout.add_widget(title)
        
        # Content
        content = Label(
            text='📱 PhotoVideoEditor\n\n'
                 'Sürüm: 1.0.0 (Mobile Test)\n'
                 'Geliştirici: AI Assistant\n'
                 'Teknoloji: Python + Kivy\n\n'
                 'Özellikler:\n'
                 '📸 Fotoğraf düzenleme\n'
                 '🎬 Video düzenleme\n'
                 '🎨 Filtreler ve efektler\n\n'
                 '🚀 Aktif geliştirme aşamasında...',
            font_size='16sp',
            halign='center',
            size_hint=(1, 0.9)
        )
        
        layout.add_widget(header_layout)
        layout.add_widget(content)
        
        self.add_widget(layout)
    
    def go_back(self, instance):
        """Ana menüye dön"""
        App.get_running_app().screen_manager.current = 'main_menu'


class PhotoVideoEditorApp(App):
    """Ana uygulama sınıfı"""
    
    def build(self):
        """UI'ı oluştur"""
        Logger.info("PhotoVideoEditor: Mobile test başlatılıyor...")
        
        # Screen Manager oluştur
        self.screen_manager = ScreenManager()
        
        # Ekranları ekle
        self.screen_manager.add_widget(SplashScreen(name='splash'))
        self.screen_manager.add_widget(MainMenuScreen(name='main_menu'))
        self.screen_manager.add_widget(PhotoEditorScreen(name='photo_editor'))
        self.screen_manager.add_widget(VideoEditorScreen(name='video_editor'))
        self.screen_manager.add_widget(TestInfoScreen(name='test_info'))
        self.screen_manager.add_widget(AboutScreen(name='about'))
        
        # Splash screen'den başla
        self.screen_manager.current = 'splash'
        
        # 3 saniye sonra ana menüye geç
        Clock.schedule_once(self.go_to_main_menu, 3)
        
        return self.screen_manager
    
    def go_to_main_menu(self, dt):
        """Ana menüye geçiş"""
        self.screen_manager.current = 'main_menu'


if __name__ == '__main__':
    PhotoVideoEditorApp().run() 